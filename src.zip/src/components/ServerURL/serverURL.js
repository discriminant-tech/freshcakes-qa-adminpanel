//--- Development Server ----------
//export const ServerUrl = 'https://saatviik.herokuapp.com/saatwiik'
export const ServerUrl = 'https://freshcakes-qa.herokuapp.com/freshcakes'

//--- Production Server ----------
//export const ServerUrl = `http://173.249.22.163:3401/saatwiik`;